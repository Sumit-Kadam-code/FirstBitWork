#include<stdio.h>
void main(){
	
	char ch = 'G';
	if(ch>='A' && ch<='Z')
		printf(" the charchter '%c' is UPPERCASE.\n",ch);
	
	 else 
	 printf(" the charcter '%c' is LOWERCASWE.\n",ch);
	 
	 
	 	
	 	
	 
	}

