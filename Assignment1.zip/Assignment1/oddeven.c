#include<stdio.h>


void main(){
	 
	 
	 int no = 9;
	 if(no%2==0)
	 {
	 	printf("number is even");
	 }
	 else
	 {
	 	printf("number is odd");
	 }
}
